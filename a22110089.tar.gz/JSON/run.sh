#!/bin/bash

python3.11 main.py $2 $1

# on other machines they might need to change this to python3 or python 
# depending on the default python > v3.10 installed on the machine.